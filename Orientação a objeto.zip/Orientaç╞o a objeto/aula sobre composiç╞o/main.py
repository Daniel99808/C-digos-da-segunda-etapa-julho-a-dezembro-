import os 
from classes import *

Jose = Cadastro(nome="Jose", cpf=12312312312)
Jose.setEndereço(28473029, 10, "Rua SENAI", "Tamoio", "Várzea")

Jose.getEndereço()

Jose.getEndereço().getRua()

print(Jose.getEndereço().getRua())