class Endereço:
    def __init__(self,cep:int,n:int,rua:str,bairro:str,cidade:str):
        self.cep = cep
        self.n = n
        self.rua = rua
        self.bairro = bairro
        self.cidade = cidade

    def __str__(self):
        return self.cep
    def getRua(self):
        return self.rua
    
class Cadastro:
    def __init__(self,nome:str,cpf:int):
        self.nome = nome
        self.cpf = cpf
        self.end = None

    def setEndereço(self,cep,n,rua,bairro,cidade):
        self.end = Endereço(cep,n,rua,bairro,cidade)

    def getEndereço(self):
        return self.end
    
    def getRua(self):
        return self.end.getRua()