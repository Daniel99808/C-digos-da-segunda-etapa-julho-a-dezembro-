from abc import *

class Poligono(ABC):
    @abstractmethod
    def __init__(self):
        self.lados = None
    def qtd_lados(self):
        return self.lados 
    def calculo_area(self):  #Todos os polígonos tem como calcular a área e todo polígono possue lados
        pass

class Quadrado(Poligono):
    def __init__ (self,lado):
        self.lados = 4 #Sobrecarga para atribuir o numero de lados da forma
        self.lado = lado

    def calculo_area(self):
        return self.lado * self.lado #calculo da area do quadrado



class Triângulo(Poligono):
    def __init__ (self,base,altura):
        self.lados = 3 #Sobrecarga para atribuir o numero de lados da forma
        self.base = base
        self.altura = altura

    def calculo_area(self):
        return(self.base * self.altura) / 2 #calculo da area do triangulo


#poligono = Poligono() (não da para instanciar o poligono)
quadrado = Quadrado(3)
triangulo = Triângulo(3,4)

print(quadrado.qtd_lados())
print(quadrado.calculo_area())
print(triangulo.qtd_lados())
print(triangulo.calculo_area())