class Animal:
    def mover(self):
        return "se move"
    

class Cachorro(Animal):
    def mover(self):
        return "se move com 4 patas"

class Peixe(Animal):
    #quando cria outro movor, acontece uma sobrecarga. Por existir essa sobrecarga, o metodo mover tem varios comportamentos
    def mover(self):
        return "nada"
    

animal = Animal()
cachorro = Cachorro()
peixe = Peixe()

print(animal.mover())
#o .mover do cachorro tem uma sobrecarga 
print(cachorro.mover())
print(peixe.mover())

#MOVER É UM MÉTODO POLIMORFICO