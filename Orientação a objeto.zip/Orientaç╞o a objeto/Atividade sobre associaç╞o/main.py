import os
from classes import *

Toyota_Corolla_H = Carro("Toyota Corolla Hybrid")
Ford_Escape_H = Carro("Ford Escape Hybrid")
Honda_Civic_G = Carro("Honda Civic")
Volkswagen_Polo = Carro("Volkswagen Polo")
Chevrolet_S10 = Carro("Chevrolet S10")
Toyota_Hilux = Carro("Toyota Hilux")

V8_motor = Motor("V8")
V6_motor = Motor("V6")
V10_motor = Motor("V10")

Roda_Aço = Roda("Roda de Aço")
Roda_Ferro = Roda("Roda de Ferro")

Toyota_Corolla_H.setPotencia(V8_motor)
Ford_Escape_H.setPotencia(V8_motor)
Honda_Civic_G.setPotencia(V6_motor)
Volkswagen_Polo.setPotencia(V6_motor)
Chevrolet_S10.setPotencia(V10_motor)
Toyota_Hilux.setPotencia(V10_motor)


Toyota_Corolla_H.setTipo(Roda_Aço)
Ford_Escape_H.setTipo(Roda_Ferro)
Honda_Civic_G.setTipo(Roda_Aço)
Volkswagen_Polo.setTipo(Roda_Ferro)
Chevrolet_S10.setTipo(Roda_Aço)
Toyota_Hilux.setTipo(Roda_Ferro)


Toyota_Corolla_H.getPotencia().getTipo()
Ford_Escape_H.getPotencia().getTipo()
Honda_Civic_G.getPotencia().getTipo()
Volkswagen_Polo.getPotencia().getTipo()
Chevrolet_S10.getPotencia().getTipo()
Toyota_Hilux.getPotencia().getTipo()


print(f"Carro = Toyota Corolla H - {Toyota_Corolla_H.getTipo().getPotencia()}")

print(f"Carro = Ford Escape H - {Ford_Escape_H.getTipo().getPotencia()}")

print(f"Carro = Honda Civic G - {Honda_Civic_G.getTipo().getPotencia()}")

print(f"Carro = Volkswagen Polo - {Volkswagen_Polo.getTipo().getPotencia()}")

print(f"Carro = Chevrolet S10 - {Chevrolet_S10.getTipo().getPotencia()}")

print(f"Carro = Toyota Hilux - {Toyota_Hilux.getTipo().getPotencia()}")