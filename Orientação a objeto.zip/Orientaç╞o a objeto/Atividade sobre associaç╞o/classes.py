# classes.py

class Motor:
    def __init__(self, tipo):
        self.tipo = tipo

    def getTipo(self):
        return self.tipo

class Roda:
    def __init__(self, tipo):
        self.tipo = tipo

    def getTipo(self):
        return self.tipo

class Carro:
    def __init__(self, nome):
        self.nome = nome
        self.potencia = None
        self.tipo = None

    def setPotencia(self, motor):
        self.potencia = motor

    def getPotencia(self):
        return self.potencia

    def setTipo(self, roda):
        self.tipo = roda

    def getTipo(self):
        return self.tipo
