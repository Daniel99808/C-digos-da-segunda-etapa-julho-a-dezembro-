from funções import *
import os

sair = None
livros = []

while sair != 0:
    escolha = menu()
    os.system("cls")

    if escolha == 1:

        livros.append(emprestimo())

    elif escolha == 2:

        listar(livros)

    elif escolha == 0:
        print("")
        os.system("pause")
        sair = 0
    else:
        print("OPÇÃO INVALIDA")
        print("")
        os.system("pause")
        os.system("cls")

