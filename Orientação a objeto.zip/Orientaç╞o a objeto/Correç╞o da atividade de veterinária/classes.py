class Livros:
    def __init__ (self, nome_livro, nome_autor, genero):
        self.nome_livro = nome_livro
        self.nome_autor = nome_autor
        self.genero = genero

    def getNome(self):
        return self.nome_livro
    
    def setNome(self, nome_livro):
        self.nome = nome_livro

    def getNomeAutor(self):
        return self.nome_autor
    
    def setNomeAutor(self, nome_autor):
        self.nome_autor = nome_autor

    def getGenero(self):
        return self.genero
    
    def setGenero(self, genero):
        self.genero = genero