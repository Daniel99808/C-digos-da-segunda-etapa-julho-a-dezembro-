#Listas
cadastros = []
cpfs = []