from classes import *
escolha = None
while escolha != 0:
    print("---- Cadastro de Animais ----")
    escolha = int(input("Qual animal quer cadastrar \n 01 -- Gato\n 02 -- Cachorro"))


    if escolha == 1:
        print("---- Cadastro de Gatos ----")
        nome = input("Informe o nome do seu Gato\n -->")
        raca = input("Informe a raça do seu Gato\n -->")

        gato = nome

        input("Informe o apelido do seu Gato\n") = Gato(nome,raca)


    elif escolha == 2:
        pass # Cachorro
    elif escolha == 0:


    else:
        print("Resposta incorreta")