class Gato:
    def __init__(self, nome, raca):
        self.nome = nome
        self.raca = raca
    
    def miar():
        print


class Cachorro:
    def __init__(self, nome, raca):
        self.nome = nome
        self.raca = raca

    def latir():
        print("Au Au!")

    def lamber():
        print("Lamb lamb")