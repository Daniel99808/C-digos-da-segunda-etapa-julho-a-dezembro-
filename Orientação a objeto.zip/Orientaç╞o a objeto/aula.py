import os

class Pessoa:
    def __init__(self,nome): #Construtor
        self.nome = nome
    def andar (self):
        print("Andando")
    def falar (self):
        print("Falando")
    def setNome (self,novo_nome):
        self.nome = novo_nome
        print(self.nome)
    def getnome (self):
        return self.nome # Os defs são métodos

Carlos = Pessoa("Carlos")
Carlos.setNome("André")
Carlos.andar()
Maria = Pessoa("Maria Clara")
Maria.andar()
print(Carlos.getnome())
print(Maria.getnome())