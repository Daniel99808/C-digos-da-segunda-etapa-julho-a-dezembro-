import os
from classes import *

Mathias = Comprador("Mathias")

maça = Produto("Maçã", "1.00", "30")
batata = Produto("Batata", "0.49", "60")
cenoura = Produto("Cenoura", "0.29", "20")

Mathias.add_produto(maça)
Mathias.add_produto(batata)
Mathias.add_produto(cenoura)

for i in Mathias.getcarrinho():
    print(f"Nome:{i.getNome()} \tValor:{i.getValor()} \tQuantidade:{i.getQuantidade()}")