class Produto():
    def __init__(self,produto,valor,quantidade):
        self.produto = produto
        self.valor = valor
        self.quantidade = quantidade

    def getNome(self):
        return self.produto
    
    def getValor(self):
        return self.valor
    
    def getQuantidade(self):
        return self.quantidade
    

class Comprador():
    def __init__(self,nome):
        self.nome = nome
        self.carrinho = []

    def add_produto(self,produto):
        self.carrinho.append(produto)
    
    def getcarrinho(self):
        return self.carrinho