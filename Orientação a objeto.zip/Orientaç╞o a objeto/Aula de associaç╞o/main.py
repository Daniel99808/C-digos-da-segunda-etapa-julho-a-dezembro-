import os
from class_associa import *


Marcos = Programador("Marcos")
Marcos.getEquip()
Macbook = Equipamento("Apple","Air")
Marcos.setEquip(Macbook)
Marcos.getEquip()
Marcos.getEquip().getMarca()
Marcos.getEquip().getModelo()


print(f"Marca = {Marcos.getEquip().getMarca()} --- Modelo = {Marcos.getEquip().getModelo()}")