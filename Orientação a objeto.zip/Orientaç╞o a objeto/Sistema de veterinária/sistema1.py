import os
from classes_vet import *

lista_gatos = []
lista_cachorros = []

while True:
    print("---- Cadastro de Animais ----")
    print("1. Cadastrar um gato")
    print("2. Cadastrar um cachorro")
    print("3. Exibir todos os gatos cadastrados")
    print("4. Exibir todos os cachorros cadastrados")
    print("5. Sair")
    
    escolha = int(input("Escolha uma opção: "))

    if escolha == 1:
        os.system('cls')
        print("---- Cadastro de Gatos ----")
        nome = input("Informe o nome do seu Gato\n -->")
        raca = input("Informe a raça do seu Gato\n -->")
        idade = int(input("Informe a idade do seu Gato\n -->"))
        dono = input("Informe o nome do dono do seu Gato\n -->")
        procedimento = input("Informe o procedimento do seu gato \n -->")
        gato = Gato(nome, raca, dono, idade, procedimento)
        lista_gatos.append(gato)
        os.system('pause')
        os.system('cls')

    if escolha == 2:
        os.system('cls')
        print("---- Cadastro de Cachorros ----")
        nome_c = input("Informe o nome do seu Cachorro\n -->")
        raca_c = input("Informe a raça do seu Cachorro\n -->")
        idade_c = int(input("Informe a idade do seu Cachorro\n -->"))
        dono_c = input("Informe o nome do dono do seu Cachorro\n -->")
        procedimento_c = input("Informe o procedimento do seu Cachorro \n -->") #oque eu coloquei aqui, vai ser igual a variavel cachorro,
        #que depois será acrescentado na lista_cachorros usando o append.

        cachorro = Cachorro(nome_c, raca_c, dono_c, idade_c, procedimento_c)#isso é uma instância, 

        lista_cachorros.append(cachorro)
        os.system('pause')
        os.system('cls')

    if escolha == 3:
        os.system('cls')
        print("--- Gatos cadastrados ---")
        print(f"Gato nº{i+1} \nNome: {gato.nome} \nRaça: {gato.raca} \nDono: {gato.dono} \nIdade: {gato.idade} \nProcedimento: {gato.procedimento}\n")
        os.system('pause')
        os.system('cls')

    if escolha == 4:
        os.system('cls')
        print("--- Cachorros cadastrados ---")
        for i in range(len(lista_cachorros)):
            cachorro = lista_cachorros[i]
        print(f"Cachorro nº{i+1} \nNome: {cachorro.nome} \nRaça: {cachorro.raca} \nDono: {cachorro.dono} \nIdade: {cachorro.idade} \nProcedimento: {cachorro.procedimento}\n")
        os.system('pause')
        os.system('cls')

    if escolha == 5:
        print("Saindo...")
        break