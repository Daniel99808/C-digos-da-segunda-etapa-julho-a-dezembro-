class Gato:
    def __init__(self,nome,raca,idade,dono,procedimento,diagnostico):
        self.nome = nome
        self.raca = raca
        self.idade = idade
        self.dono = dono
        self.procedimento = procedimento

class Cachorro:
    def __init__(self,nome,raca,idade,dono,procedimento):
        self.nome = nome
        self.raca = raca
        self.idade = idade
        self.dono = dono
        self.procedimento = procedimento