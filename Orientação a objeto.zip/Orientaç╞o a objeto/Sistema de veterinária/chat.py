from cachorro import Cachorro
from gato import Gato

# Listas para armazenar as instâncias de gatos e cachorros
lista_gatos = []
lista_cachorros = []

# Função para cadastrar um novo gato
def cadastrar_gato():
    nome = input("Digite o nome do gato: ")
    raca = input("Digite a raça do gato: ")
    dono = input("Digite o nome do dono: ")
    idade = int(input("Digite a idade do gato: "))
    gato = Gato(nome, raca, dono, idade)
    lista_gatos.append(gato)

# Função para cadastrar um novo cachorro
def cadastrar_cachorro():
    nome = input("Digite o nome do cachorro: ")
    raca = input("Digite a raça do cachorro: ")
    dono = input("Digite o nome do dono: ")
    idade = int(input("Digite a idade do cachorro: "))
    cachorro = Cachorro(nome, raca, dono, idade)
    lista_cachorros.append(cachorro)

# Função principal
def main():
    while True:
        print("\nOpções:")
        print("1. Cadastrar um gato")
        print("2. Cadastrar um cachorro")
        print("3. Exibir todos os gatos cadastrados")
        print("4. Exibir todos os cachorros cadastrados")
        print("5. Sair")
        
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            cadastrar_gato()
        elif opcao == "2":
            cadastrar_cachorro()
        elif opcao == "3":
            print("\nGatos cadastrados:")
            for gato in lista_gatos:
                print(gato)
        elif opcao == "4":
            print("\nCachorros cadastrados:")
            for cachorro in lista_cachorros:
                print(cachorro)
        elif opcao == "5":
            print("Saindo...")
            break
        else:
            print("Opção inválida. Tente novamente.")
