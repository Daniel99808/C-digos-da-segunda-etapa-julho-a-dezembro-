import os
from classes_vet import *

lista_gatos = []
lista_cachorros = []

x = 0
y = 0

while True:
        print("---- Cadastro de Animais ----")
        print("1. Cadastrar um gato")
        print("2. Cadastrar um cachorro")
        print("3. Exibir todos os gatos cadastrados")
        print("4. Exibir todos os cachorros cadastrados")
        print("5. Sair")
        
        escolha = int(input("Escolha uma opção: "))

        if escolha == 1:
            os.system('cls')
            print("---- Cadastro de Gatos ----")
            nome = input("Informe o nome do seu Gato\n -->")
            raca = input("Informe a raça do seu Gato\n -->")
            idade = int(input("Informe a idade do seu Gato\n -->"))
            dono = input("Informe o nome do dono do seu Gato\n -->")
            procedimento = input("Informe o procedimento do seu gato \n -->")
            gato = Gato(nome, raca, dono, idade, procedimento)
            lista_gatos.append(gato)
            os.system('pause')
            os.system('cls')


        elif escolha == 2:
            os.system('cls')
            print("---- Cadastro de Cachorros ----")
            nome_c = input("Informe o nome do seu Cachorro\n -->")
            raca_c = input("Informe a raça do seu Cachorro\n -->")
            idade_c = int(input("Informe a idade do seu Cachorro\n -->"))
            dono_c = input("Informe o nome do dono do seu Cachorro\n -->")
            procedimento_c = input("Informe o procedimento do seu Cachorro \n -->")
            cachorro = Cachorro(nome, raca, dono, idade, procedimento)
            lista_cachorros.append(cachorro)
            os.system('pause')
            os.system('cls')


        elif escolha == 3:
            os.system('cls')
            x += 1
            print(f"--- Gatos cadastrados --- \nGato nº{x} \nNome:{nome} \nRaça:{raca} \nDono:{dono} \nIdade:{idade} \nProcedimento: {procedimento}")
            os.system('pause')
            os.system('cls')

        elif escolha == 4:
            os.system('cls')
            y += 1
            print(f"--- Cachorros cadastrados --- \nCachorro nº{y} \nNome:{nome_c} \nRaça:{raca_c} \nDono:{dono_c} \nIdade:{idade_c} \n Procedimento: {procedimento_c}")
            os.system('pause')
            os.system('cls')

        elif escolha == 5:
            print("Saindo...")
            break