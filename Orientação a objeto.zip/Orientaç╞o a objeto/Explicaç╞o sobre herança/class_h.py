class Animal:
    # Construtor
    def __init__(self,nome,idade,dono):
        self.__nome = nome
        self.__idade = idade
        self.__dono = dono

    def comer(self):
        print("Estou comendooo !!")

    def brincar(self):
        print("Estou brincando")
    
    #Metedos GETs
    def getNome(self):
        return self.__nome
    def getIdade(self):
        return self.__idade
    def getDono(self):
        return self.__dono
    #Metedos SETs
    def setNome(self, nome):
        self.__nome = nome
    def setIdade(self, idade):
        self.__idade = idade
    def setDono(self, dono):
        self.__dono = dono

    def __str__(self):
        return self.__nome
    
class Cachorro(Animal):

    def __init__(self, nome, idade, dono , raca):
        super().__init__(nome, idade, dono)
        self.__raca = raca

    def getRaca(self):
        return self.__raca
    def setRaca(self, raca):
        self.__raca = raca
    
    def latir(self):
        print("Estou latindoo !!")

class Gato(Animal):

    def __init__(self, nome, idade, dono, cor):
        super().__init__(nome,idade,dono)
        self.__cor = cor

    def getCor(self):
        return self.__cor
    def setCor(self, cor):
        self.__cor = cor

    def miar(self):
        print("Estou miando !!")

gatinho = Gato("Zen", 1, "Leticia","Preto e Branco")
cachorrinho = Cachorro ("Noah", 9, "Carlos", "Golden")

print(cachorrinho.getNome())
print(gatinho.getCor())

print(cachorrinho)