batata = (20,90)
print (batata)