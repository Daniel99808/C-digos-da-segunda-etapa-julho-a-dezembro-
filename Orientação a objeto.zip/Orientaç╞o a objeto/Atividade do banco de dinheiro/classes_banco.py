class Banco:
    def __init__(self, nome, idade, rg_do_dono, senha):
        self.nome = nome
        self.idade = idade
        self.rg_do_dono = rg_do_dono
        self.senha = senha
        self.saldo_corrente = 0
        self.saldo_poupanca = 0

    def getNome(self):
        return self.nome

    def getIdade(self):
        return self.idade

    def getDono(self):
        return self.rg_do_dono

    def getSenha(self):
        return self.senha

    def getSaldoCorrente(self):
        return self.saldo_corrente

    def getSaldoPoupanca(self):
        return self.saldo_poupanca

    def deposito(self, valor):
        self.saldo_corrente += valor
        print(f"Você fez um depósito de R${valor}. O saldo da sua conta corrente agora é R${self.saldo_corrente}")

    def sacar(self, valor):
        if valor > self.saldo_corrente:
            print("Você não tem dinheiro suficiente para saque.")
        else:
            self.saldo_corrente -= valor
            print(f"Saque de R${valor} realizado. \nSaldo corrente: R${self.saldo_corrente}")

    def aplicar_poupanca(self, valor):
        if valor > self.saldo_corrente:
            print("Você não tem dinheiro suficiente para aplicar na poupança.")
        else:
            self.saldo_corrente -= valor
            self.saldo_poupanca += valor
            print(f"Aplicação de R${valor} na poupança realizada. \nSaldo Poupança: R${self.saldo_poupanca} \nSaldo Corrente: R${self.saldo_corrente}")

class Cadastro(Banco):
    def __init__(self, nome, idade, rg_do_dono, senha):
        super().__init__(nome, idade, rg_do_dono, senha)
        print("Conta criada com sucesso")

    def exibir_dados_da_conta(self):
        print(f"Nome: {self.nome}, Idade: {self.idade}, RG: {self.rg_do_dono}")


class Acesso(Cadastro):
    def __init__(self, nome, idade, rg_do_dono, senha):
        super().__init__(nome, idade, rg_do_dono, senha)

    def autenticação(self, nome, senha, rg_do_dono):
        if self.nome == nome and self.senha == senha and self.rg_do_dono == rg_do_dono:
            print(f"Acesso autorizado para {nome}.")
            return True
        else:
            print("Senha, nome ou RG inválidos.")
            return False