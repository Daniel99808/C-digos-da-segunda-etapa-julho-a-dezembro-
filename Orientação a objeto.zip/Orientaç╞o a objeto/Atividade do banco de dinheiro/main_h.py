import os
from funcoes_h import *

contas = []
sair = None
while sair != 0:
    menu()
    try:
        escolha = int(input("--> "))
    except ValueError:
        print("Escolha inválida. Por favor, insira um número.")
        os.system("pause")
        os.system("cls")
        continue

    os.system("cls")
    match escolha:
        case 1:
            cadastro(contas)
        case 2:
            conta = acessar()
            if conta:
                conta_acessada(conta)
            else:
                print("Conta não encontrada.")
        case 3:
            print("Saindo...")
            sair = 0 
        case _:
            print("OPÇÃO INVÁLIDA")
            os.system("pause")
            os.system("cls")
