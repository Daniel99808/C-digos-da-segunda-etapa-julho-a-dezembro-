class Banco():
    def _init_(self, nome, idade, rg_do_dono, senha):
        self.nome = nome
        self.idade = idade
        self.rg_do_dono = rg_do_dono
        self.senha = senha
        self.saldo_corrente = 0
        self.saldo_poupanca = 0

    def getNome(self):
        return self.nome

    def getIdade(self):
        return self.idade

    def getDono(self):
        return self.rg_do_dono

    def getSenha(self):
        return self.senha

    def getSaldoCorrente(self):
        return self.saldo_corrente

    def getSaldoPoupança(self):
        return self.saldo_poupanca



    def sacar(self, valor):
        if valor > self.saldo_corrente:
            print("Saldo insuficiente para saque.")
        else:
            self.saldo_corrente -= valor
            print(f"Saque de {valor} realizado. Saldo atual: {self.saldo_corrente}")

    def aplicar_poupanca(self, valor):
        if valor > self.saldo_corrente:
            print("Saldo insuficiente para aplicar na poupança.")
        else:
            self.saldo_corrente -= valor
            self.saldo_poupanca += valor
            print(f"Aplicação de {valor} na poupança realizada. Saldo Poupança: {self.saldo_poupanca}, Saldo Corrente: {self.saldo_corrente}")


class Cadastro(Banco):
    def _init_(self, nome, idade, rg_do_dono, senha):
        super()._init_(nome, idade, rg_do_dono, senha)
        print(f"Cadastro concluído para {nome}. Conta criada com sucesso!")

    def exibir_dados_da_conta(self):
        print(f"Nome: {self.nome}, Idade: {self.idade}, RG: {self.rg_do_dono}")


class Acesso(Cadastro):
    def _init_(self, nome, idade, rg_do_dono, senha):
        super()._init_(nome, idade, rg_do_dono, senha)

    def autenticação(self, nome, senha):
        if self.nome == nome and self.senha == senha:
            print(f"Acesso autorizado para {nome}.")
            return True
        else:
            print("Acesso negado. Nome ou senha incorretos.")
            return False


# Funções
import os
contas = []

def menu():
    print("---SISTEMA DE CONTA BANCÁRIA---")
    print("1 - CADASTRAR UMA CONTA")
    print("2 - ACESSAR CONTA")
    print("3 - SAIR")

def cadastro():
    while True:
        print("---- CADASTRO DE CONTAS ----")
        print("01 - CADASTRAR")
        print("02 - VOLTAR")
        print("")
        cadastro_opcao = input("Qual opção deseja? \n--> ")

        if cadastro_opcao == '2':
            return None
        elif cadastro_opcao != '1':
            print("Opção inválida. Tente novamente.")
            os.system("pause")
            os.system('cls')
            continue

        os.system("cls")
        print("---- CADASTRAR CONTA ----")
        nome = input("Informe o seu nome\n--> ")
        idade = input("Informe a sua idade\n--> ")
        rg_do_dono = input("Informe seu RG\n--> ")
        senha = input("Informe sua senha\n--> ")

        try:
            idade = int(idade)
        except ValueError:
            print("Idade inválida. Use números.")
            os.system("pause")
            os.system("cls")
            continue

        nova_conta = Cadastro(nome, idade, rg_do_dono, senha)
        contas.append(nova_conta)
        os.system("pause")
        os.system("cls")
        return nova_conta

def acessar():
    print("---- ACESSAR CONTA ----")
    nome = input("Informe o seu nome\n--> ")
    senha = input("Insira a senha\n--> ")

    for conta in contas:
        if conta.autenticar(nome, senha):
            os.system("pause")
            os.system("cls")
            return conta

    print("Conta não encontrada ou senha incorreta.")
    os.system("pause")
    os.system("cls")
    return None

def ver_saldo(conta):
    print(f"Conta Corrente: {conta.getSaldoCorrente()}")
    print(f"Conta Poupança: {conta.getSaldoPoupanca()}")
    os.system("pause")
    os.system("cls")

def sacar_dinheiro(conta):
    try:
        valor = float(input("Quanto deseja sacar?\n--> "))
        conta.sacar(valor)
    except ValueError:
        print("Valor inválido. Tente novamente.")
    os.system("pause")
    os.system("cls")

def aplicar_poupanca(conta):
    try:
        valor = float(input("Quanto deseja aplicar na poupança?\n--> "))
        conta.aplicar_poupanca(valor)
    except ValueError:
        print("Valor inválido. Tente novamente.")
    os.system("pause")
    os.system("cls")

def conta_acessada(conta):
    while True:
        print("---- ACESSAR CONTA ----")
        print("01 - Ver Saldo")
        print("02 - Conta Corrente: Sacar Dinheiro")
        print("03 - Conta Poupança: Aplicar Dinheiro")
        print("04 - Voltar")
        print("")
        escolha = input("Qual opção deseja? \n--> ")

        if escolha == '1':
            ver_saldo(conta)
        elif escolha == '2':
            sacar_dinheiro(conta)
        elif escolha == '3':
            aplicar_poupanca(conta)
        elif escolha == '4':
            return
        else:
            print("Opção inválida.")
        os.system("pause")
        os.system("cls")

def main():
    sair = None
    while sair != 0:
        menu()
        escolha = input("--> ")

        os.system("cls")
        if escolha == '1':
            cadastro()
        elif escolha == '2':
            conta = acessar()
            if conta:
                conta_acessada(conta)
        elif escolha == '3':
            print("Saindo...")
            os._exit(3.5)
        else:
            print("OPÇÃO INVÁLIDA")
            os.system("pause")
            os.system("cls")