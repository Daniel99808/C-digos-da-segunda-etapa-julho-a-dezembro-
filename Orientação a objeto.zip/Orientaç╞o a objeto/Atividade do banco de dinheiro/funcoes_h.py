import os
from classes_banco import *
contas = []

def menu():
    print("--- SISTEMA DE CONTA BANCÁRIA ---")
    print("1 - CADASTRAR UMA CONTA")
    print("2 - ACESSAR CONTA")
    print("3 - SAIR")

def cadastro(contas):
    while True:
        print("---- CADASTRO DE CONTAS ----")
        print("01 - CADASTRAR")
        print("02 - VOLTAR")
        print("")

        try:
            cadastro_opcao = int(input("Qual opção deseja? \n--> "))
        except ValueError:
            print("Valor inválido. Tente novamente.")
            os.system("pause")
            os.system('cls')
            continue
        
        if cadastro_opcao == 1:
            os.system("cls")
            print("---- CADASTRAR CONTA ----")
            nome = input("Informe o seu nome\n--> ")
            idade = input("Informe a sua idade\n--> ")
            rg_do_dono = input("Informe seu RG\n--> ")
            senha = input("Informe sua senha\n--> ")
            try:
                idade = int(idade)
            except ValueError:
                print("Idade inválida. Use números.")
                os.system("pause")
                os.system("cls")
                continue
            nova_conta = Cadastro(nome, idade, rg_do_dono, senha)
            contas.append(nova_conta)
            os.system("pause")
            os.system("cls")
            return nova_conta
        elif cadastro_opcao == 2:
            os.system('cls')
            return None
        else:
            print("OPÇÃO INVÁLIDA")
            os.system("pause")
            os.system("cls")

def acessar():
    print("---- ACESSAR CONTA ----")
    nome = input("Informe o seu nome\n--> ")
    senha = input("Insira a senha\n--> ")
    rg_do_dono = input("Insira o RG do dono\n--> ")

    for conta in contas:
        if conta.autenticação(nome, senha, rg_do_dono):
            os.system("pause")
            os.system("cls")
            return conta
    print("Conta não encontrada ou senha incorreta.")
    os.system("pause")
    os.system("cls")
    return None

def ver_saldo(conta):
    print(f"Conta Corrente: R${conta.getSaldoCorrente()}")
    print(f"Conta Poupança: R${conta.getSaldoPoupanca()}")
    os.system("pause")
    os.system("cls")

def sacar_dinheiro(conta):
    try:
        valor = float(input("Quanto deseja sacar?\n--> "))
        conta.sacar(valor)
    except ValueError:
        print("Valor inválido. Tente novamente.")
    os.system("pause")
    os.system("cls")

def aplicar_poupanca(conta):
    try:
        valor = float(input("Quanto deseja aplicar na poupança?\n--> "))
        conta.aplicar_poupanca(valor)
    except ValueError:
        print("Valor inválido. Tente novamente.")
    os.system("pause")
    os.system("cls")

def conta_acessada(conta):
    while True:
        print("---- MENU DA CONTA ----")
        print("01 - Ver Saldo")
        print("02 - Conta Corrente: Sacar Dinheiro")
        print("03 - Conta Poupança: Aplicar Dinheiro")
        print("04 - Ver informações da conta")
        print("05 - Voltar")
        print("")

        try:
            conta_acess = int(input("Qual opção deseja? \n--> "))
        except ValueError:
            print("Valor inválido. Tente novamente.")
            os.system("pause")
            os.system('cls')
            continue
        
        match conta_acess:
            case 1:
                ver_saldo(conta)
            case 2:
                sacar_dinheiro(conta)
            case 3:
                aplicar_poupanca(conta)
            case 4:
                conta.exibir_dados_da_conta()
            case 5:
                return
            case _:
                print("Opção inválida.")
                os.system("pause")
                os.system("cls")