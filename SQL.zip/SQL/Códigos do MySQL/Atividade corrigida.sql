-- CRIAR BASE DE DADOS -- DDL
create database kitanda;

-- USAR BASE DE DADOS --
use kitanda;

-- CRIAR TABELA -- DDL
create table produtos(
    id int(3) auto_increment,
    produto varchar(15),
    tipo varchar(10),
    quantidade int(6),
    valor decimal(5,2), -- 999,99 é o máximo que pode chegar --
    primary key (id)
);

-- INSERIR DADOS NA TABELA -- DML
insert into produtos(produto, tipo, quantidade, valor) values
	('batatainglesa', 'vegetal', 63, 1),
    ('melancia', 'fruta', 20, 10),
    ('morango', 'fruta', 132, 1.10),
    ('abacaxi','fruta', 37, 12),
    ('abacate','fruta', 43, 3),
    ('alface','vegetal', 50, 2),
    ('cenoura','vegetal', 30, 1.20),
    ('tomate','vegetal', 38, 1.05);
    
-- --------------------------------------------------------------------

-- Listar todo os dados da Tabela -- DQL
select 
	id as ID,
    produto as PROD,
    tipo as TIPO,
    quantidade as QTD,
    valor as V_UNI
from produtos;

-- Listar produtos com QTD acima de 10
select  id as ID,
		tipo as TIPO,
		quantidade as QTD,
		valor as VALOR_UNI,
		quantidade * valor as VALOR_TOTAL
from 
    produtos
where quantidade > 10 				-- where é um filtro! --
order by 
	quantidade ASC;
    
-- Media dos valores totais - DQL
select AVG(quantidade * valor) as MEDIA_VALOR_TOTAL from produtos;

--
select 
	SUM(quantidade * valor) from produto; -- Tira a prova real e depois divide pelo número de quantidadev --

-- Valor total por produto - DQL
select produto as PROD,
quantidade * valor as VALOR_TOTAL
from 
	produto;
    
-- Valor total por tipo - DQL
select 
	tipo as TIPO,
    quantidade * valor as VALOR_TOTAL
from 
	produto
where tipo = 'fruta',
SUM(tipo)
	


