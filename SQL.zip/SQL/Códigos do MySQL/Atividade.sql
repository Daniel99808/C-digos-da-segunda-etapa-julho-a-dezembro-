create database kitanda;

use kitanda;

create table produtos(
    id varchar(15) not null,
    tipo varchar(10) not null,
    quantidade int(6) not null,
    valor int(7) not null
);

insert into produtos(id, tipo, quantidade, Valor_Uni) values
	('batatainglesa', 'vegetal', '63', '1'),
    ('melancia', 'fruta', '20', '10'),
    ('morango', 'fruta', '132', '1,10'),
    ('abacaxi','fruta','37','12'),
    ('abacate','fruta','43','3'),
    ('alface','vegetal','50','2'),
    ('cenoura','vegetal','30','1,20'),
    ('tomate','vegetal','38','1,05');

select Valor_Uni * quantidade as Valor_total from produtos
where Quantidade > 10;

SELECT SUM(quantidade * valor) AS Valor_Total_Acumulado
FROM produtos;

SELECT AVG(Valor_total);

SELECT AVG(quantidade * valor) AS Media_Valor_Total
FROM produtos;

SELECT COUNT(DISTINCT valor) AS Valores_Distintos
FROM produtos;

SELECT tipo, quantidade FROM produto ORDER BY quantidade ASC;


select * from produtos;
