create database livraria;
-- -----------------------
use livraria;
-- -----------------------
create table livros(
	id int(3) auto_increment,
    livro varchar(30),
    id_autor int(3),
    primary key (id),
    foreign key (id_autor) references autor (id)
);
-- -------------------------
create table autor(
	id int(3) auto_increment,
    autor varchar(30),
    primary key (id)
);
-- -------------------------
insert into livros(livro) values (
	('A culpa é das estrelas', 1),
    ('Viagem ao centro da terra', 2),
    ('1822',3),
    ('Clean Code', null));




