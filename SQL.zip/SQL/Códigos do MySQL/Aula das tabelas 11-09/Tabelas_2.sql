-- Usando o Inner
SELECT 
	A.livro as NOME_LIVRO,
    B.autor as NOME_AUTOR
FROM 	
	livros as A
	INNER JOIN autor as B ON A.id_autor = B.id;
-- ---------------------------------------------
SELECT 
	A.livro as NOME_LIVRO,
	B.autor as NOME_AUTOR
FROM
	livros as A
    LEFT JOIN autor as B ON A.id_autor = B.id;
-- ---------------------------------------------
SELECT
    A.livro as NOME_LIVRO,
    B.autor as NOME_AUTOR
FROM 	
	livros as A
	RIGHT JOIN autor as B ON A.id_autor = B.id;
-- ---------------------------------------------
SELECT
    A.livro as NOME_LIVRO,
    B.autor as NOME_AUTOR
FROM 	
	livros as A
	FULL OUTER JOIN autor as B ON A.id_autor = B.id;


