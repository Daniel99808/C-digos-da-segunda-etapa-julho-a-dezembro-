-- ------ Comando para criar a base
create database Cliente;

-- ------ User DataBase
USE Cliente;

-- ------ Comando para criar a Tabela
create table Dados_dos_clientes (Nome VARCHAR(45), Sobrenome VARCHAR(45), IDADE INT, CPF VARCHAR(45));

-- ------ Comando para Inserir dados
insert into Dados_dos_clientes (Nome, Sobrenome, Idade, CPF)
VALUES ('Pedro','Henrique','22','123.123.123-12');

-- ------ Comando para Alterar dados
update Dados_dos_clientes
SET Nome = João, Sobrenome = Silva;
