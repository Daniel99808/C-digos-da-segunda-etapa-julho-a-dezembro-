-- 1 ----
select p.nome as produtos, e.nome as empresa
from produto as p
inner join empresa as e on p.id_empresa = e.id;

-- 2 ----
select p.nome, p.estoque
from produto as p
inner join empresa as e on p.id_empresa = e.id
where e.nome = 'produto';

-- 3 ----
select p.*, (p.estoque * p.valor_final) as total_estoque
from produto as p;

-- 4 ----
select e.nome as empresa, COUNT(p.nome) as tipo_de_produto
from empresa as e
left join produto as p on p.id_empresa = e.id
group by e.nome;

-- 5 ----
select e.nome as empresa, p.nome as produto, p.valor_final as maior_valor_final
from empresa as e
inner join produto as p on p.id_empresa = e.id
order by p.valor_final desc
limit 1;

-- 6 ----
select p.nome as estoque_zerado
from produto as p
where p.estoque = 0;

-- 7 ----
select SUM(p.estoque * p.valor_final) as valor_de_tudo
from produto as p;
-- --------------------------------------------------
-- 1 ----
select nome as produtos from produto;

-- 2 ----
select nome, estoque from produto;


-- 3 ----
select *, (estoque * valor_final) as total_estoque from produto;


-- 4 ----
select *, COUNT(nome) as tipo_de_produto from produto inner join empresa, cliente;


-- 5 ----
select MAX(valor_final) as maior_valor_final from produto;

-- 6 ----
select estoque as estoque_zerado from produto
where estoque = 0;

-- 7 ----
select SUM(p.estoque * p.valor_final) as valor_de_tudo from produto p;


-- 9 ----
select e.nome as empresa, SUM(p.estoque * p.valor_final) as valor_total_estoque
from empresa as e
inner join produto as p on e.id = p.id_empresa
group by e.nome
order by valor_total_estoque desc
limit 1;


