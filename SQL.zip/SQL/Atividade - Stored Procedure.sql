-- Procedure de Cadastro de Novos Clientes----
use jooin;
Delimiter //
Create procedure Cadastro_Cliente (in Nome varchar(20), in CPF int(11),in Data_Nascimento int(8), in Telefone int(11), in Email varchar(30))
Begin
insert into cliente
Select
			nome = Nome,
            cpf = CPF,
            data_nascimento = Data_Nascimento,
            celular = Telefone,
            email = Email
from
cliente;
End //
Delimiter ;

-- Call ----
Call Cadastro_Cliente('Daniel', 83740562801, 19082007, 11913333176, 'danielfonsecamonteiro07@gmail.com');