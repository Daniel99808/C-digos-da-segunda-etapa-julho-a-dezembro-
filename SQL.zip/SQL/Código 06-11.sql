use database jooin
-- Procedure ----
Delimiter //
Create procedure produto_valor_acima(in Valor_Min Int)
Begin 
	Select 
		  nome,
		  truncate(Valor_final,2)
from 
	Produto
where Valor_final > Valor_min;
End //
Delimiter ;

-- Call ----
Call produto_valor_acima(10);



-- Procedure 2 ----

use database jooin

Delimiter //
	Create procedure calcular_desconto (in valor_prod int, out desconto int)
    Begin
	      set desconto = valor_prod - (valor_prod * 0.1);
	End //
Delimiter ;
set @resultado = 0;
Call calcular_desconto(100,@resultado);
select @resultado;