-- Exercícios novos --
use jooin;


-- Exercício 1 ----
create view vw_exercicio1 as
SELECT cliente.nome,
       COUNT(*) AS N_Transações,
       SUM(transacao.quantidade) AS Total_Transações
FROM transacao
JOIN cliente ON transacao.id_transacao = cliente.id
GROUP BY cliente.nome
HAVING SUM(transacao.quantidade) > (SELECT AVG(transacao.quantidade) FROM transacao);

-- VIEW 1 ----
SELECT *
FROM vw_exercicio1;

-- Exercício 2 ----
SELECT produto.nome as Produtos,
       cliente.nome as Clientes, 
       SUM(transacao.quantidade) AS Quantidade_Total
FROM transacao
JOIN produto ON transacao.id_transacao = produto.id
JOIN cliente ON transacao.id_transacao = cliente.id
GROUP BY produto.nome, cliente.nome
HAVING SUM(transacao.quantidade) > (SELECT AVG(quantidade) FROM transacao);

-- Exercício 3 ----
SELECT cliente.nome, 
       COUNT(DISTINCT produto.nome) AS Produtos_Distintos
FROM transacao
JOIN produto ON transacao.id_transacao = produto.id
JOIN cliente ON transacao.id_transacao = cliente.id
GROUP BY cliente.nome
HAVING COUNT(DISTINCT produto.nome) >= 2;


-- Desafio ----
	
SELECT
	A.nome as PRODUTO,
    B.nome_fantasia as EMPRESA,
    A.valor_bruto as VALOR_BRUTO,
    A.margem_lucro as MARGEM_LUCRO,
    truncate(((A.valor_bruto - A.imposto) - A.margem_lucro),2) as VALOR_FINAL
    
FROM
	produto as A
JOIN empresa as B on A.empresa = B.id
ORDER BY
	A.margem_lucro asc;