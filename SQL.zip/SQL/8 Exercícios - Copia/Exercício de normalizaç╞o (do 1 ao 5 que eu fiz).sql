use jooin;
-- 1 --------
select
	A.nome_fantasia as EMPRESA,
    B.nome as CLIENTE,
    valor_total as VALOR_TOTAL_DA_TRANSAÇÃO
from 
	transacao as C
join empresa as A on C.id_produto = A.id
join cliente as B on C.id_cliente = B.id
where
	A.id = 5;
-- 2 ---------
select
	B.nome as CLIENTE,
	count(A.id_transaçao) as N_TRASAÇAO,
    sum(A.valor_final) as Valor_Final
    from
	transacao as A
join
	cliente as B on A.id_cliente = B.id
group by B.nome;
-- 3 --------
select
		B.nome as PRODUTO,
    B.marca as MARCA,
    SUM(quantidade) as QUANTIDADE
from
	transacao as A
join produto as B on A.id_produto = B.id
group by B.nome;
-- 4 --------
select
		B.nome_fantasia as EMPRESA,
    SUM(valor_total) as VALOR_TOTAL
from
	transacao as A
join empresa as B on A.id_produto = B.id
group by B.nome;
-- 5 --------
select
		B.nome as CLIENTE,
    SUM(quantidade) as QUANTIDADE,
    SUM(valor_total) as VALOR_TOTAL
from
	transacao as A
join cliente as B on A.id_cliente = B.id
where 
	A.valor_total >= 600
group by B.nome