create database jooin;
use jooin;
