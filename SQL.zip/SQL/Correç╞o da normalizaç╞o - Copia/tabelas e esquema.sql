-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: jooin
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) DEFAULT NULL,
  `cpf` float DEFAULT NULL,
  `data_nascimento` int(8) DEFAULT NULL,
  `celular` float DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `item_comprado` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_comprado` (`item_comprado`),
  CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`item_comprado`) REFERENCES `produto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'João Silva',12345700000,19900101,11987700000,'joao@example.com',1),(2,'Maria Santos',98765400000,19851225,11888900000,'maria@example.com',2),(3,'Carlos Oliveira',45678900000,19780315,11777800000,'carlos@example.com',3),(4,'Ana Souza',12309900000,19870228,12000000000,'ana@example.com',4),(5,'Pedro Lima',54321700000,19930415,11666700000,'pedro@example.com',5),(6,'Juliana Pereira',98712300000,19801020,115,'juliana@example.com',6),(7,'Mariana Castro',65498700000,19850912,11444400000,'mariana@example.com',7),(8,'Fernando Santos',98765400000,19820507,11333300000,'fernando@example.com',8),(9,'Lucas Oliveira',45632200000,19890730,11222200000,'lucas@example.com',9),(10,'Gabriela Silva',32198800000,19980125,11888900000,'gabriela@example.com',10),(11,'Bruno Souza',12365500000,19841218,11777800000,'bruno@example.com',11),(12,'Patrícia Lima',98745600000,19800210,11666700000,'patricia@example.com',12),(13,'Rafaela Pereira',65412400000,19900905,115,'rafaela@example.com',13),(14,'Thiago Castro',32179000000,19760703,11444400000,'thiago@example.com',14),(15,'Vanessa Santos',78965400000,19890115,11333300000,'vanessa@example.com',15),(16,'Rodrigo Oliveira',98765400000,19811228,11222200000,'rodrigo@example.com',16),(17,'Camila Silva',45678900000,19950410,11888900000,'camila@example.com',17),(18,'Diego Souza',12398700000,19830807,11777800000,'diego@example.com',18),(19,'Aline Lima',98765400000,19921120,11666700000,'aline@example.com',19),(20,'Marcela Pereira',65432200000,19790415,115,'marcela@example.com',20),(21,'Roberto Castro',32165500000,19860518,11444400000,'roberto@example.com',1),(22,'Laura Santos',78912400000,19930928,11333300000,'laura@example.com',2),(23,'Gustavo Oliveira',98765400000,19800710,11222200000,'gustavo@example.com',3),(24,'Isabela Silva',45698700000,19850105,11888900000,'isabela@example.com',4),(25,'Ricardo Souza',12379000000,19980320,11777800000,'ricardo@example.com',5),(26,'Tatiane Lima',98745600000,19730815,11666700000,'tatiane@example.com',6),(27,'Vinícius Pereira',65412400000,19870910,115,'vinicius@example.com',7),(28,'Carolina Castro',32198800000,19801103,11444400000,'carolina@example.com',8),(29,'Luiz Santos',78932200000,19911028,11333300000,'luiz@example.com',9),(30,'Nathália Oliveira',98765400000,19760214,11222200000,'nathalia@example.com',10),(31,'Paulo Silva',45678900000,19840430,11888900000,'paulo@example.com',11),(32,'Fernanda Souza',12365500000,19920405,11777800000,'fernanda@example.com',12),(33,'André Lima',98712300000,19820908,11666700000,'andre@example.com',13),(34,'Beatriz Pereira',65498700000,19780923,115,'beatriz@example.com',14),(35,'José Castro',32179000000,19951210,11444400000,'jose@example.com',15),(36,'Sandra Santos',78965400000,19821205,11333300000,'sandra@example.com',16),(37,'Leandro Oliveira',98765400000,19770818,11222200000,'leandro@example.com',17),(38,'Cristina Silva',45632200000,19931007,11888900000,'cristina@example.com',18),(39,'Daniel Souza',12365500000,19860412,11777800000,'daniel@example.com',19),(40,'Renata Lima',98745600000,19910417,11666700000,'renata@example.com',20),(41,'Luciana Pereira',65412400000,19721030,115,'luciana@example.com',21),(42,'Marcos Castro',32165400000,19890525,11444400000,'marcos@example.com',21),(43,'Simone Santos',78912400000,19830518,11333300000,'simone@example.com',3),(44,'Henrique Oliveira',98765400000,19980410,11222200000,'henrique@example.com',4),(45,'Catarina Silva',45698700000,19810715,11888900000,'catarina@example.com',5),(46,'Lucas Souza',12379000000,19761020,11777800000,'lucas@example.com',6),(47,'Mariana Lima',98745600000,19941205,11666700000,'mariana@example.com',7),(48,'Diego Pereira',65412400000,19800308,115,'diego@example.com',8),(49,'Carla Castro',32198800000,19960214,11444400000,'carla@example.com',9),(50,'Roberto Santos',78932200000,19811227,11333300000,'roberto@example.com',10),(51,'João Silva',12345700000,19900101,11987700000,'joao@example.com',11);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empresa` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) DEFAULT NULL,
  `nome_fantasia` varchar(20) DEFAULT NULL,
  `cnpj` float DEFAULT NULL,
  `endereco` varchar(50) DEFAULT NULL,
  `cidade` varchar(20) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `pais` varchar(20) DEFAULT NULL,
  `telefone_01` float DEFAULT NULL,
  `telefone_02` float DEFAULT NULL,
  `celular` float DEFAULT NULL,
  `representante` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa`
--

LOCK TABLES `empresa` WRITE;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
INSERT INTO `empresa` VALUES (1,'Empresa da Trapalhad','Trapalhada Inc.',98765400000000,'Avenida da Confusão, 456','Bagunçópolis','Confusão','Desordemlândia',5551230000,5559880000,5553330000,'Sr. Desastre'),(2,'Empresa dos Problema','Problemas Corp.',12345700000000,'Rua dos Erros, 789','Caosville','Incerto','Desenrolândia',4449880000,4445560000,4442220000,'Sra. Engano'),(3,'Fábrica da Confusão ','Confusion Factory',55555600000000,'Estrada da Desorganização, 123','Desajustópolis','Descontrole','Desarrumação',6661110000,6664450000,6667780000,'Dr. Caos'),(4,'Empresa do Caos Ltda','Caos e Cia.',65498700000000,'Rua da Desordem, 789','Desregulópolis','Desorganização','Descontroslândia',7778890000,7776670000,7773330000,'Sr. Bagunça'),(5,'Indústria do Equívoc','Equívoco Ind.',78965400000000,'Avenida do Engano, 456','Desorientópolis','Desgovernado','Desconhecido',8889990000,8882220000,8884450000,'Sra. Engano'),(6,'Empresa da Bagunça &','Bagunça Ltda.',99988900000000,'Travessa da Desordem, 789','Bagunçalândia','Bagunçado','Bagunçalândia',7774450000,7772230000,7773340000,'Sr. Confusão'),(7,'Companhia do Descont','Descontrole Corp.',32165500000000,'Rua do Descontrole, 123','Desatino','Desregrado','Descompasso',5556670000,5558890000,5551110000,'Sr. Caos'),(8,'Familia Senai Ltda.','Odio Descontrolado.',1233210000000,'Rua Roberto Manje, 3000','Jundiai','São Paulo','Brasil',5556670000,5558880000,5551120000,'Sr. Carlos'),(9,'Dev. Sistemas Corp.','Tech Informatica.',1233210000000,'Rua Roberto Manje, 3000','Jundiai','São Paulo','Brasil',5556670000,5558880000,5551120000,'Sr. Jamal');
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produto`
--

DROP TABLE IF EXISTS `produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produto` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) DEFAULT NULL,
  `marca` varchar(20) DEFAULT NULL,
  `empresa` int(3) DEFAULT NULL,
  `estoque` int(5) DEFAULT NULL,
  `valor_bruto` float DEFAULT NULL,
  `imposto` float DEFAULT NULL,
  `margem_lucro` float DEFAULT NULL,
  `valor_final` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empresa` (`empresa`),
  CONSTRAINT `produto_ibfk_1` FOREIGN KEY (`empresa`) REFERENCES `empresa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produto`
--

LOCK TABLES `produto` WRITE;
/*!40000 ALTER TABLE `produto` DISABLE KEYS */;
INSERT INTO `produto` VALUES (1,'Smartwatch','WristTech',1,80,150,0.06,0.25,198.75),(2,'Tablet','TouchPad',2,70,300,0.08,0.2,388.8),(3,'Câmera','SnapLens',3,90,250,0.07,0.22,326.35),(4,'Impressora','PrintTech',4,60,200,0.05,0.18,247.8),(5,'Monitor','ViewScreen',5,40,180,0.04,0.15,215.28),(6,'Caixa de Som','SoundWave',6,120,80,0.03,0.2,98.88),(7,'Roteador','NetLink',7,95,70,0.02,0.25,89.25),(8,'Webcam','EyeSee',8,75,45,0.01,0.15,52.2675),(9,'HD Externo','DataVault',1,110,120,0.03,0.18,145.848),(10,'Carregador Portátil','PowerUp',2,130,25,0.02,0.2,30.6),(11,'Cabo USB','LinkCable',3,140,10,0.01,0.15,11.615),(12,'Hub USB','ConnectAll',4,105,15,0.01,0.18,17.877),(13,'Adaptador HDMI','ScreenLink',5,85,20,0.01,0.2,24.24),(14,'Case para HD','SafeCase',6,100,8,0.005,0.15,9.246),(15,'Cooler para Notebook','CoolDown',7,65,12,0.005,0.2,14.472),(16,'Pendrive','DataDrive',8,115,18,0.005,0.18,21.3462),(17,'Placa de Vídeo','Graphix',1,45,300,0.07,0.3,417.3),(18,'Memória RAM','SpeedRAM',2,55,80,0.03,0.25,103),(19,'Processador','SpeedCore',3,50,600,0.06,0.35,600),(20,'Placa-Mãe','CoreBoard',4,30,150,0.05,0.3,204.75),(21,'Mesa','TOPTOP',5,800,155,0.099,0.6,272.552);
/*!40000 ALTER TABLE `produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transacao`
--

DROP TABLE IF EXISTS `transacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transacao` (
  `id_transacao` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) DEFAULT NULL,
  `id_produto` int(11) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `valor_total` decimal(10,2) DEFAULT NULL,
  `data_transacao` date DEFAULT NULL,
  PRIMARY KEY (`id_transacao`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_produto` (`id_produto`),
  CONSTRAINT `transacao_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`),
  CONSTRAINT `transacao_ibfk_2` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transacao`
--

LOCK TABLES `transacao` WRITE;
/*!40000 ALTER TABLE `transacao` DISABLE KEYS */;
INSERT INTO `transacao` VALUES (1,1,3,2,220.75,'2023-01-11'),(2,2,1,4,480.00,'2023-02-05'),(3,3,2,1,120.90,'2023-03-19'),(4,4,4,3,345.50,'2023-04-22'),(5,5,5,6,670.00,'2023-05-10'),(6,6,6,2,150.00,'2023-06-02'),(7,7,7,1,130.00,'2023-07-14'),(8,8,9,7,875.00,'2023-08-25'),(9,9,8,2,299.00,'2023-09-18'),(10,10,10,4,444.25,'2023-10-01'),(11,11,3,5,550.00,'2023-11-08'),(12,12,1,1,111.00,'2023-12-30'),(13,13,5,3,450.00,'2023-02-15'),(14,14,7,2,230.00,'2023-03-29'),(15,15,4,6,699.90,'2023-04-17'),(16,16,8,5,980.00,'2023-05-23'),(17,17,2,2,240.00,'2023-06-30'),(18,18,10,4,560.00,'2023-07-10'),(19,19,9,1,139.99,'2023-08-20'),(20,20,6,3,345.50,'2023-09-02'),(21,21,1,1,100.00,'2023-10-11'),(22,22,3,7,760.75,'2023-11-25'),(23,23,5,2,210.00,'2023-12-16'),(24,24,2,5,550.00,'2023-01-28'),(25,25,8,3,660.30,'2023-02-13'),(26,26,7,4,890.00,'2023-03-07'),(27,27,6,2,120.25,'2023-04-26'),(28,28,10,1,95.00,'2023-05-15'),(29,29,9,3,395.00,'2023-06-03'),(30,30,4,6,725.50,'2023-07-09'),(31,31,1,4,520.00,'2023-08-27'),(32,32,2,5,600.75,'2023-09-19'),(33,33,3,1,119.50,'2023-10-22'),(34,34,5,3,410.00,'2023-11-05'),(35,35,6,2,240.75,'2023-12-12'),(36,36,7,4,660.00,'2023-01-25'),(37,37,9,5,870.00,'2023-02-06'),(38,38,10,1,99.90,'2023-03-20'),(39,39,8,3,375.00,'2023-04-08'),(40,40,2,2,198.50,'2023-05-13'),(41,41,4,5,615.75,'2023-06-24'),(42,42,1,3,320.00,'2023-07-06'),(43,43,5,4,745.00,'2023-08-31'),(44,44,3,1,129.99,'2023-09-16'),(45,45,7,2,245.00,'2023-10-30'),(46,46,6,6,899.75,'2023-11-13'),(47,47,8,1,150.00,'2023-12-21'),(48,48,9,5,870.50,'2023-01-04'),(49,49,10,2,230.00,'2023-02-18'),(50,50,4,3,370.75,'2023-03-15'),(51,1,1,2,100.50,'2023-01-15'),(52,2,3,1,50.00,'2023-02-20'),(53,3,4,5,250.00,'2023-03-10'),(54,4,2,3,150.75,'2023-04-05'),(55,5,5,1,75.25,'2023-05-22'),(56,6,6,2,120.00,'2023-06-18'),(57,7,7,4,180.00,'2023-07-01'),(58,8,8,3,200.00,'2023-08-12'),(59,9,9,2,140.00,'2023-09-30'),(60,10,10,1,70.00,'2023-10-14'),(61,11,11,5,350.00,'2023-11-02'),(62,12,12,2,110.00,'2023-12-25'),(63,13,13,4,160.50,'2023-02-10'),(64,14,14,3,90.00,'2023-03-15'),(65,15,15,2,100.00,'2023-04-21'),(66,16,16,1,40.00,'2023-05-01'),(67,17,17,3,130.75,'2023-06-05'),(68,18,18,5,300.00,'2023-07-20'),(69,19,19,2,100.25,'2023-08-10'),(70,20,20,1,60.00,'2023-09-15'),(71,21,1,2,110.00,'2023-10-05'),(72,22,2,4,170.00,'2023-11-11'),(73,23,3,1,50.50,'2023-12-01'),(74,24,4,3,130.00,'2023-01-18'),(75,25,5,5,250.00,'2023-02-28'),(76,26,6,2,120.75,'2023-03-12'),(77,27,7,4,180.25,'2023-04-03'),(78,28,8,3,160.00,'2023-05-15'),(79,29,9,1,70.75,'2023-06-18'),(80,30,10,2,90.00,'2023-07-25'),(81,31,11,5,350.00,'2023-08-09'),(82,32,12,4,210.50,'2023-09-11'),(83,33,13,2,100.00,'2023-10-21'),(84,34,14,1,50.00,'2023-11-03'),(85,35,15,4,180.00,'2023-12-22'),(86,36,16,3,150.00,'2023-01-30'),(87,37,17,2,120.00,'2023-02-16'),(88,38,18,5,300.00,'2023-03-19'),(89,39,19,1,60.00,'2023-04-29'),(90,40,20,4,190.00,'2023-05-11'),(91,41,1,2,115.00,'2023-06-09'),(92,42,2,3,135.00,'2023-07-13'),(93,43,3,1,55.00,'2023-08-01'),(94,44,4,2,95.00,'2023-09-27'),(95,45,5,4,180.00,'2023-10-19'),(96,46,6,3,140.00,'2023-11-10'),(97,47,7,1,65.00,'2023-12-05'),(98,48,8,5,310.00,'2023-01-19'),(99,49,9,2,120.00,'2023-02-25'),(100,50,10,4,210.00,'2023-03-10');
/*!40000 ALTER TABLE `transacao` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-02 10:42:20