-- ATIVIDADE 01
create view vw_empresa_cliente_total as
	select
		c.id as ID,
		c.nome_fantasia as Empresa,
		d.nome as Cliente,
		a.valor_total as Total
	from
		transacao as a
	left join produto as b on a.id_produto = b.id
	left join empresa as c on b.empresa = c.id
	left join cliente as d on a.id_cliente = d.id;

-- ------------------------------------

select 
	*
from 
	vw_empresa_cliente_total
where
	id = 3;

-- ATIVIDADE 02
create view vw_cliente_transacao as
	select
		B.nome as CLIENTE,
		count(A.id_transacao) as N_TRANSACAO,
		sum(A.valor_total) AS VALOR_TOTAL
	from
		transacao as A
	join cliente as B on A.id_cliente = B.id
	group by
		B.nome;
	-- having 
		-- count(A.id_transacao) > 1;
-- -------------------------------------------
select
	*
from
	vw_cliente_transacao;

-- ATIVIDADE 03
create view vw_qtd_produto_venda as 
	select
		A.id_produto as ID,
		B.nome as NOME,
		B.marca as MARCA,
		sum(A.quantidade) as QTD_TOTAL
	from
		transacao as A
	join 
		produto as B on A.id_produto = B.id
	group by
		B.nome
	order by
		QTD_TOTAL desc;
	
select 
	*
from
	vw_qtd_produto_venda
where
	id = 10;
    
-- ATIVIDADE 04
create view vw_valor_total_empresa as 
	select
		resultado.empresa as EMPRESA,
        sum(resultado.valor_total) as VALOR_TOTAL
	from(
		select
			c.nome_fantasia as EMPRESA,
			B.nome as PRODUTO,
			truncate(B.valor_final,2) as VALOR,
			sum(A.quantidade) as QTD,
			truncate(B.valor_final * sum(A.quantidade),2) as VALOR_TOTAL
		from
			transacao as A		
		left join
			produto as B on A.id_produto = B.id
		left join
			empresa as C on B.empresa = C.id
		group by 
			PRODUTO ) as resultado
	group by
		resultado.empresa;


select 
	*
from 
	vw_valor_total_empresa;
    
-- ATIVIDADE 05
create view vw_valor_total_cliente as
	select
		resultado.cliente AS Cliente,
		count(resultado.cliente) as Transações,
		sum(resultado.valor_final) as Valor_Final
	from(
		select
			B.nome as Cliente,
			c.nome as Produto,
			d.nome_fantasia as Empresa,
			truncate(C.valor_final, 2) as Valor,
			A.quantidade as Qtd, 
			truncate(C.valor_final * A.quantidade, 2) as Valor_Final
		from
			transacao as A
		join
			cliente as B on A.id_cliente = b.id
		join
			produto as C on A.id_produto = c.id
		join
			empresa as D on C.empresa = D.id
		order by
			Cliente) as resultado
	group by
		resultado.cliente;

select
	*
from
	vw_valor_total_cliente
where
	valor_final > 2000;