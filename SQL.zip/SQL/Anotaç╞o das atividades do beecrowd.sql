select name, street -- selecionar as colunas que deseja printar --
from customers -- seleciona a tabela --
where city = 'Porto Alegre'; -- pra printar algo específico --
-- ----------------------------------------------------
select id,name -- selecionar as colunas que deseja printar
from products -- seleciona a tabela que tem as colunas
where price > 10 and price < 100; -- where é um filtro, então vai print em específico.
-- ----------------------------------------------------
select max (price), min (price) -- printar valor máximo de uma coluna
from products; -- seleciona a tabela
-- ----------------------------------------------------
SELECT p.id, p.name -- mesmos nomes, renomear para ficar mais organizado, esse "p" é de products
FROM products p INNER JOIN categories c ON -- esse "p" é de products  o INNER JOIN serve para combinar linhas de duas ou mais tabelas com base em uma coluna chave compartilhada entre elas
     p.id_categories = c.id -- o p. serve para renomear e especificar de qual tabela é a coluna, e o c.id é para o categories.
WHERE c.name LIKE 'super%'; -- o c.name é da a coluna name da tabela categories e o "LIKE" é utilizado para encontrar registros específicos dentro de um padrão de escrita
-- ----------------------------------------------------
select city
from providers
order by city asc; -- o asc serve para listar a coluna em forma crescente, tanto em numero quanto letra.
-- ----------------------------------------------------
select round(AVG(price), 2) asprice -- O round serve para printar as casas depois da vírgula

from products;
-- ----------------------------------------------------
select m.id, m.name -- esse m. serve para renomear
from movies m INNER JOIN prices p ON -- o on é quase um in
    m.id_prices = p.id 
where categorie ='Promotion';-- onde "nome da coluna" tiver um valor igual a 'nome do valor'
-- ----------------------------------------------------
select distinct city -- seleciona a coluna e fala os elementos sem repetir
from customers ;
-- ----------------------------------------------------
select
    products.name AS products, -- o AS renomeia para um valor 
    providers.name AS providers -- ""
from
    products
        INNER JOIN providers ON	products.id_providers = providers.id -- from products + from providers, isso que o INNER JOIN faz
where
    providers.name = 'Ajax SA';-- O nome do providers tem que ser igual a Ajax SA, por isso o "where"
-- ----------------------------------------------------
SELECT
    c.name, r.rentals_date -- Seleciona a coluna nome da tabela customers e a mesma coisa com o rental
FROM
    customers c
        INNER JOIN rentals r
            ON c.id = r.id_customers 
WHERE
    r.rentals_date BETWEEN '2016-09-01' AND '2016-09-30' -- O between é uma ferramenta para filtrar valores em um intervalo específico
