-- Exercícios novos --
use jooin;


-- Exercício 1 ----
create view vw_paramarciamedaração as
SELECT cliente.nome,
       COUNT(*) AS N_Transações,
       SUM(transacao.quantidade) AS Total_Transações
FROM transacao
JOIN cliente ON transacao.id_transacao = cliente.id
GROUP BY cliente.nome
HAVING SUM(transacao.quantidade) > (SELECT AVG(transacao.quantidade) FROM transacao);

-- VIEW 1 ----
SELECT *
FROM vw_paramarciamedaração;

-- Exercício 2 ----
SELECT produto.nome as Produtos,
       cliente.nome as Clientes, 
       SUM(transacao.quantidade) AS Quantidade_Total
FROM transacao
JOIN produto ON transacao.id_transacao = produto.id
JOIN cliente ON transacao.id_transacao = cliente.id
GROUP BY produto.nome, cliente.nome
HAVING SUM(transacao.quantidade) > (SELECT AVG(quantidade) FROM transacao);

-- Exercício 3 ----
SELECT cliente.nome, 
       COUNT(DISTINCT produto.nome) AS Produtos_Distintos
FROM transacao
JOIN produto ON transacao.id_transacao = produto.id
JOIN cliente ON transacao.id_transacao = cliente.id
GROUP BY cliente.nome
HAVING COUNT(DISTINCT produto.nome) >= 2;